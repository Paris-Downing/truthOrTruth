package com.snp.tOrT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TOrTApplication {

	public static void main(String[] args) {
		SpringApplication.run(TOrTApplication.class, args);
	}

}
